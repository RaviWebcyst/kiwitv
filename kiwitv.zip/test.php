<?php

 phpinfo();