<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Paykun\Checkout\Payment;
use App\Paykun as PaymentModel;
use App\Transactions;
use App\User;
use Auth;
use Session;
use App\SubscriptionPlan;


class paykunController extends Controller
{
    public $gateway;
  
    public function __construct()
    {
        $this->gateway = new Payment(env('PAYKUN_MERCHANT_ID'), env('PAYKUN_ACCESS_TOKEN'), env('PAYKUN_KEY_SECRET'), false); // here we pass last parameter as false to enable sandbox mode.
    }
 
    public function index()
    {
        return view('pages.paykun');
    }
 
    public function charge(Request $request)
    {
     
       
        // if($request->input('submit'))
        // {
            try {
 
                $this->gateway->setCustomFields(array('udf_1' => 'test')); //remove or comment this line when go live
 
                $this->gateway->initOrder('ORD'.uniqid(), 'My Product Name', $request->input('amount'), url('paymentsuccess'), url('paymenterror'));
 
                // Add Customer
                $this->gateway->addCustomer('', '', '');
 
                // Add Shipping address
                $this->gateway->addShippingAddress('', '', '', '', '');
 
                // Add Billing Address
                $this->gateway->addBillingAddress('', '', '', '', '');
 
                echo $this->gateway->submit();
            } catch(Exception $e) {
                return $e->getMessage();
            }
        // }
    }
 
    public function payment_success(Request $request)
    {
 
       
        if ($request->input('payment-id'))
        {
           
            
            $transactionData = $this->gateway->getTransactionInfo($request->input('payment-id'));
         
            if ($transactionData['status'])
            {
               
                $arr_transaction = $transactionData['data']['transaction'];
                
                // Check if payment_id already exists in the database
                $isPaymentExist = PaymentModel::where('payment_id', $arr_transaction['payment_id'])->first();
                
                if(!$isPaymentExist)
                {

                   

                    $payment = new PaymentModel;
                    $payment->payment_id = $arr_transaction['payment_id'];
                    $payment->payer_email = $arr_transaction['customer']['email_id'];
                    $payment->payer_mobile = $arr_transaction['customer']['mobile_no'];
                    $payment->amount = $arr_transaction['order']['gross_amount'];
                    $payment->payment_status = $arr_transaction['status'];
                    $payment->save();

                    $payment_trans = new Transactions;

                    $user_id=Auth::user()->id;
      
                    $user = User::findOrFail($user_id);
          
                    $plan_id = Session::get('plan_id');
                    
                    $plan_info = SubscriptionPlan::where('id',$plan_id)->where('status','1')->first();
                  
                    $plan_days=$plan_info->plan_days;
                    // print_r(strtotime(date('m/d/Y', strtotime("+$plan_days days"))));
                  
                    // die;
                    $user->plan_id = $plan_id;                    
                    $user->start_date = strtotime(date('m/d/Y'));             
                    $user->exp_date = strtotime(date('m/d/Y', strtotime("+$plan_days days")));
                    
                    $user->paykun_payment_id = $arr_transaction['payment_id'];
                    $user->plan_amount = $arr_transaction['order']['gross_amount'];
                    //$user->subscription_status = 0;
                    $user->save();

                    $res = response()->json($arr_transaction);
                    $payment_trans->user_id = Auth::user()->id;
                    $payment_trans->email = $arr_transaction['customer']['email_id'];
                    $payment_trans->plan_id =  $plan_id;
                    $payment_trans->gateway = 'PayKun';
                    $payment_trans->payment_status=$arr_transaction['status'];
                    $payment_trans->response = $res;
                    $payment_trans->payment_amount = $arr_transaction['order']['gross_amount'];
                    $payment_trans->payment_id = $arr_transaction['payment_id'];
                    $payment_trans->date = strtotime(date('m/d/Y H:i:s'));
                    if( $payment_trans->save())  {
                        return redirect('dashboard');

                    }                  
                   
                }
          
                return "Payment is successful. Your transaction id is: ". $arr_transaction['payment_id'];
            }
        }
    }
 
    public function payment_error(Request $request)
    {
        return "Something went wrong. Try again later.";
    }
}

